##from tkinter import *
##pencere = Tk()
##pencere.title("erdincdonmez.com")
##pencere.geometry("600x300")

import turtle
turtle.forward(100)
