def selamla():
    def sabah():
        print("Günaydın")
    def ogle():
        print("İyi günler")
    ogle()

# selamla()