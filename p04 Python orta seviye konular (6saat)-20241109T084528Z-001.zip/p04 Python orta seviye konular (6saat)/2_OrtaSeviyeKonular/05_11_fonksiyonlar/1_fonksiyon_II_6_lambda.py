
onekle = lambda a : a + 10
print(onekle(5))

def yirmiEkle(xx):
    xx += 20
    return xx

print (yirmiEkle(23))