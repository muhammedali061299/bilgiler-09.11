##   <h1>H1 Başlık</h1>
##   <h2>H2 Başlık</h2>
##   <h3>H3 Başlık</h3>
##   <h4>H4 Başlık</h4>
##   <h5>H5 Başlık</h5>
##   <h6>H6 Başlık</h6>

degisken = "a"
degisken = "b"

pano = [
    [0,1,0,0,0,0,0,]
    ]
