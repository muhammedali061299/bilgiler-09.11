x = 'print(55+5)'
eval(x)
