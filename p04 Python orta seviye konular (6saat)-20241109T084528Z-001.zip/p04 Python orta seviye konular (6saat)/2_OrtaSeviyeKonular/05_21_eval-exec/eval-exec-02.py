x = input("Bir python komutu girin: ")
eval(x)
eval(input())
